/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.productsalesreport;

/**
 *
 * @author RC_Student_Lab
 */
public interface IProductSales {
    double calculateTotalSales();
    double calculateAverageSales();
    double findMaximumSales();
    double findMinimumSales();
}
