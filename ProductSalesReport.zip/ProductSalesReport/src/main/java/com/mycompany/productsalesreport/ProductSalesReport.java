/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.productsalesreport;

/**
 *
 * @author RC_Student_Lab
 */
public class ProductSalesReport {

    public static void main(String[] args) {
        // Sales data: Rows represent years (Year 1, Year 2), Columns represent quarters (Q1, Q2, Q3, Q4)
        int[][] salesData = {
            {21000, 23000, 25000, 27000}, // Year 1 sales
            {22000, 24000, 26000, 28000}  // Year 2 sales
        };

        // Single-dimensional array to store year totals for easier overall calculation
        int[] yearTotals = new int[salesData.length];

        int grandTotal = 0;
        int maxSale = Integer.MIN_VALUE;
        int minSale = Integer.MAX_VALUE;
        int totalQuarters = 0;

        System.out.println("Product Sales Report:\n");

        // Iterate through years (rows)
        for (int i = 0; i < salesData.length; i++) {
            int annualTotal = 0;
            System.out.println("Year " + (i + 1) + " Sales:");

            // Iterate through quarters (columns)
            for (int j = 0; j < salesData[i].length; j++) {
                int currentSale = salesData[i][j];
                annualTotal += currentSale;
                totalQuarters++;

                // Update min and max sales for the entire period
                if (currentSale > maxSale) {
                    maxSale = currentSale;
                }
                if (currentSale < minSale) {
                    minSale = currentSale;
                }
                System.out.println("  Quarter " + (j + 1) + ": $" + currentSale);
            }
            yearTotals[i] = annualTotal;
            grandTotal += annualTotal;
            System.out.println("  Annual Total: $" + annualTotal + "\n");
        }

        double averageSale = (double) grandTotal / totalQuarters;

        System.out.println("\n--- Overall Two-Year Summary ---");
        System.out.println("Total Sales for the two-year period: $" + grandTotal);
        System.out.printf("Average Sales per quarter: $%.2f%n", averageSale);
        System.out.println("Maximum Sale amount: $" + maxSale);
        System.out.println("Minimum Sale amount: $" + minSale);
    }
}
