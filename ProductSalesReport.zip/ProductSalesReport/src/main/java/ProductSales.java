package com.mycompany.productsalesreport;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_Lab
 */
public class ProductSales implements IProductSales {
    // 2D array to store sales data (2 years, 4 quarters each)
    private final double[][] salesData;
    // Single array for flat representation of data to simplify min/max calculations
    private final double[] flatSalesData;

    public ProductSales(double[][] data) {
        this.salesData = data;
        this.flatSalesData = flattenArray(data);
    }

    public ProductSales() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }



    // Helper method to convert 2D array to 1D array
    private double[] flattenArray(double[][] twoDArray) {
        int totalQuarters = 0;
        for (double[] year : twoDArray) {
            totalQuarters += year.length;
        }
        double[] flatArray = new double[totalQuarters];
        int index = 0;
        for (double[] year : twoDArray) {
            for (double sales : year) {
                flatArray[index++] = sales;
            }
        }
        return flatArray;
    }

    @Override
    public double calculateTotalSales() {
        double total = 0;
        for (double sales : flatSalesData) {
            total += sales;
        }
        return total;
    }

    @Override
    public double calculateAverageSales() {
        // Average is total sales divided by the total number of quarters
        return calculateTotalSales() / flatSalesData.length;
    }

    @Override
    public double findMaximumSales() {
        double maxSales = Double.MIN_VALUE;
        for (double sales : flatSalesData) {
            if (sales > maxSales) {
                maxSales = sales;
            }
        }
        return maxSales;
    }

    @Override
    public double findMinimumSales() {
        double minSales = Double.MAX_VALUE;
        for (double sales : flatSalesData) {
            if (sales < minSales) {
                minSales = sales;
            }
        }
        return minSales;
    }

    // Method to display the quarterly sales data in a table format
    public void displaySalesData() {
        System.out.println("Product Sales Data (2 Years, 4 Quarters):");
        System.out.println("------------------------------------------");
        for (int i = 0; i < salesData.length; i++) {
            System.out.printf("Year %d: ", (i + 1));
            for (int j = 0; j < salesData[i].length; j++) {
                System.out.printf("Q%d: $%.2f\t", (j + 1), salesData[i][j]);
            }
            System.out.println();
        }
        System.out.println("------------------------------------------");
    }

    public double calculateTotalSales(double[] sales) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public double calculateAverageSales(double[] sales) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public double findMaximumSales(double[] sales) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public double findMinimumSales(double[] sales) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public double findMinimumSales(double[] sales) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
