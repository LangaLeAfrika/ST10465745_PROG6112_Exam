/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.productsalesreport.ProductSales;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_Lab
 */
// In the 'test' package
import org.junit.jupiter.api.Test;

public class ProductSalesTest {

    @Test
    void testCalculateTotalSales() {
        ProductSales salesCalculator = new ProductSales();
        double[] sales = {100.0, 200.0, 300.0};
        assertEquals(600.0, salesCalculator.calculateTotalSales(sales), 0.001);
    }

    @Test
    void testCalculateAverageSales() {
        ProductSales salesCalculator = new ProductSales();
        double[] sales = {100.0, 200.0, 300.0};
        assertEquals(200.0, salesCalculator.calculateAverageSales(sales), 0.001);
    }

    @Test
    void testFindMaximumSales() {
        ProductSales salesCalculator = new ProductSales();
        double[] sales = {100.0, 250.0, 50.0, 300.0};
        assertEquals(300.0, salesCalculator.findMaximumSales(sales), 0.001);
    }

    @Test
    void testFindMinimumSales() {
        ProductSales salesCalculator = new ProductSales();
        double[] sales = {100.0, 250.0, 50.0, 300.0};
        assertEquals(50.0, salesCalculator.findMinimumSales(sales), 0.001);
    }

    @Test
    void testEmptySalesArray() {
        ProductSales salesCalculator = new ProductSales();
        double[] sales = {};
        assertEquals(0.0, salesCalculator.calculateTotalSales(sales), 0.001);
        assertEquals(0.0, salesCalculator.calculateAverageSales(sales), 0.001);
        assertEquals(0.0, salesCalculator.findMaximumSales(sales), 0.001); // Assuming 0 for empty array
        assertEquals(0.0, salesCalculator.findMinimumSales(sales), 0.001); // Assuming 0 for empty array
    }
}